clear,  clc
rng(0);

%% Settings
n_run = 2;
max_d = 10;
n_train = 50;  % number of data points
sigma = 0.25;

MSE_DC = zeros(n_run, max_d);
MSE_MARS = zeros(n_run, max_d);
MSE_MLP = zeros(n_run, max_d);
MSE_KNN = zeros(n_run, max_d);


%% Synthetic data
for run = 1:n_run
    disp("----------------------------------------------------------------------")
    disp(run)
    for d = 1:max_d
        
        X_train = randn(n_train, d);
        y_train = regfunction(X_train, sigma);
        
        X_test = randn(10000, d);
        y_test = regfunction(X_test, 0);
        
        %% D.C
        n_flips = 2;
        Rn = rademacher_dc(X_train(1:2*floor(n_train/2),:), n_flips);
        lambda_0 = 4*Rn*n_train;
        f_hat= auto_tune_dc_fit(y_train, X_train, lambda_0, "regression");
        y_hat_test = f_hat(X_test);
        MSE_DC(run, d) = mean((y_hat_test-y_test).^2)/var(y_test);
        
        %% MLP      
        net = auto_tune_mlp(y_train, X_train);
        y_hat_test =  net(X_test')';
        MSE_MLP(run,d) = mean((y_hat_test-y_test).^2)/var(y_test);
                
        %% MARS
%         MARS_params = aresparams2('maxFuncs', 101);
%         [model, ~, resultsEval] = aresbuild(X_train, y_train, MARS_params);
%         results = arestest(model, X_test, y_test);
%         MSE_MARS(run,d) = (results.MSE)/var(y_test);
        
        %% KNN
        Mdl = auto_tune_KNN(y_train, X_train, "regression");
        y_hat_test = predict(Mdl,X_test);
        MSE_KNN(run,d) = mean((y_hat_test-y_test).^2)/var(y_test);
        
    end
end


%% Plotting
errorbar(1:max_d,mean(MSE_DC),-1.96*std(MSE_DC)/sqrt(n_run),...
    1.96*std(MSE_DC)/sqrt(n_run),'LineWidth', 2,'MarkerSize', 10); hold on

errorbar(1:max_d,mean(MSE_MARS),-1.96*std(MSE_MARS)/sqrt(n_run),...
    1.96*std(MSE_MARS)/sqrt(n_run),'LineWidth', 2,'MarkerSize', 10);

errorbar(1:max_d,mean(MSE_MLP),-1.96*std(MSE_MLP)/sqrt(n_run),...
    1.96*std(MSE_MLP)/sqrt(n_run),'LineWidth', 2,'MarkerSize', 10);

errorbar(1:max_d,mean(MSE_KNN),-1.96*std(MSE_KNN)/sqrt(n_run),...
    1.96*std(MSE_KNN)/sqrt(n_run),'LineWidth', 2,'MarkerSize', 10);

legend("DC", "MARS", "MLP", "KNN", 'FontSize',15)

ylabel("Normalized MSE", 'FontSize',15)
xlabel("dimension", 'FontSize',15)
xticks(1:2:max_d)

%% DC plot
% regression_plot_dc(X_train,y_train, @(X) regfunction(X,0), f_hat);

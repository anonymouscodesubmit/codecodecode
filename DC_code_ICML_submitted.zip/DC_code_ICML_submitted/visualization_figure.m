clear,  clc
rng(0);

%% Settings
d = 2;
n = 85;  % number of data points
sigma = 0.5;

X_train = rand(n, d);
y_train = local_regfunction(X_train, sigma);
n_train = n;

X_test = rand(10000, d);
y_test = local_regfunction(X_test, 0);

%% D.C
n_flips = 2;
Rn = rademacher_dc(X_train(1:2*floor(n_train/2),:), n_flips);
lambda_0 = 4*Rn*n_train;
f_hatCV = auto_tune_dc_fit(y_train, X_train, lambda_0, "regression");
f_hatTh = dc_fit(y_train, X_train, lambda_0);


%% DC plot
regression_plot_dc(X_train,y_train, @(X) local_regfunction(X,0), f_hatCV, f_hatTh);

figure(1)
zlabel("$\hat f(x)$","Interpreter", "latex","FontSize", 20)
xlabel("$x_1$","Interpreter", "latex","FontSize", 20)
ylabel("$x_2$","Interpreter", "latex","FontSize", 20)
xticks([])
yticks([])

figure(2)
zlabel("$\hat f(x)$","Interpreter", "latex","FontSize", 20)
xlabel("$x_1$","Interpreter", "latex","FontSize", 20)
ylabel("$x_2$","Interpreter", "latex","FontSize", 20)
xticks([])
yticks([])

figure(3)
zlabel("$f(x)$","Interpreter", "latex","FontSize", 20)
xlabel("$x_1$","Interpreter", "latex","FontSize", 20)
ylabel("$x_2$","Interpreter", "latex","FontSize", 20)
xticks([])
yticks([])


%% local function

function y = local_regfunction(X, sigma)
[n, d] = size(X);

X = 3*pi*X;

if d > 1
    y = sin(X(:,1)) + cos(X(:,2)) + 3*log(abs(X(:,1)+X(:,2))+1);
else
    y = sin(X)  + 3*log(abs(X) +1);
end
y = y + sigma*randn(n,1);
end

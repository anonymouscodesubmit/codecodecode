function y = regfunction(X, sigma)
[n, d] = size(X);


y = (sum(X,2)/sqrt(d)).^2 + sin(pi*sum(X,2)/sqrt(d)) ;

y = y + sigma*randn(n,1);

end